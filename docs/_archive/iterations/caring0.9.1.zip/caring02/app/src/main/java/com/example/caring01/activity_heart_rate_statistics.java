package com.example.caring01;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class activity_heart_rate_statistics extends AppCompatActivity {

    private GraphView heartRateGraph;
    private TextView txtMaxHeartRate, txtAvgHeartRate, txtMinHeartRate;
    private DatabaseReference databaseReference;

    private TextView tabDaily, tabWeekly, tabMonthly, tabYearly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_statistics);

        heartRateGraph = findViewById(R.id.heartRateGraph);
        txtMaxHeartRate = findViewById(R.id.maxHeartRate);
        txtAvgHeartRate = findViewById(R.id.avgHeartRate);
        txtMinHeartRate = findViewById(R.id.minHeartRate);

        tabDaily = findViewById(R.id.tab_daily);
        tabWeekly = findViewById(R.id.tab_weekly);
        tabMonthly = findViewById(R.id.tab_monthly);
        tabYearly = findViewById(R.id.tab_yearly);

        // Firebase 데이터베이스 참조 가져오기
        databaseReference = FirebaseDatabase.getInstance().getReference("USER/StatsData/heartRate/2024");

        // 탭 클릭 리스너 설정
        tabDaily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayDailyData();
            }
        });

        tabWeekly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayWeeklyData();
            }
        });

        tabMonthly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayMonthlyData();
            }
        });

        tabYearly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayYearlyData();
            }
        });

        // 기본적으로 오늘의 데이터를 표시
        displayDailyData();
    }

    private void displayDailyData() {
        String currentDate = getCurrentDate();

        // 경로 확인을 위한 로그 추가
        Log.d("DateCheck", "Fetching data for current date: " + currentDate);

        databaseReference.child("monthlyData/11/weeklyData/week1/dailyData").child(currentDate)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            int max = dataSnapshot.child("max").getValue(Integer.class);
                            int min = dataSnapshot.child("min").getValue(Integer.class);
                            int avg = dataSnapshot.child("average").getValue(Integer.class);

                            txtMaxHeartRate.setText(max + " BPM");
                            txtMinHeartRate.setText(min + " BPM");
                            txtAvgHeartRate.setText(avg + " BPM");

                            updateGraph(new int[]{avg, max, min}, "Daily Heart Rate");
                        } else {
                            Log.d("DataError", "No data found for date: " + currentDate);
                            displayNoDataMessage();
                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.d("DatabaseError", "Database error: " + databaseError.getMessage());
                    }
                });
    }

    private void displayWeeklyData() {
        databaseReference.child("monthlyData/11/weeklyData/week1").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int avg = dataSnapshot.child("weeklyAverage").getValue(Integer.class);

                    List<DataPoint> dataPoints = new ArrayList<>();
                    int max = Integer.MIN_VALUE;
                    int min = Integer.MAX_VALUE;

                    for (DataSnapshot dailySnapshot : dataSnapshot.child("dailyData").getChildren()) {
                        int dailyAvg = dailySnapshot.child("average").getValue(Integer.class);
                        int dailyMax = dailySnapshot.child("max").getValue(Integer.class);
                        int dailyMin = dailySnapshot.child("min").getValue(Integer.class);

                        dataPoints.add(new DataPoint(dataPoints.size(), dailyAvg));

                        if (dailyMax > max) max = dailyMax;
                        if (dailyMin < min) min = dailyMin;
                    }

                    txtMaxHeartRate.setText(max + " BPM");
                    txtMinHeartRate.setText(min + " BPM");
                    txtAvgHeartRate.setText(avg + " BPM");

                    updateGraph(dataPoints.toArray(new DataPoint[0]), "Weekly Heart Rate");
                } else {
                    Log.d("DataError", "Weekly data not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void displayMonthlyData() {
        databaseReference.child("monthlyData/11").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int avg = dataSnapshot.child("monthlyAverage").getValue(Integer.class);

                    txtMaxHeartRate.setText("N/A");
                    txtMinHeartRate.setText("N/A");
                    txtAvgHeartRate.setText(avg + " BPM");

                    updateGraph(new int[]{avg}, "Monthly Heart Rate");
                } else {
                    Log.d("DataError", "Monthly data not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void displayYearlyData() {
        databaseReference.child("yearlyAverage").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int avg = dataSnapshot.getValue(Integer.class);

                    txtMaxHeartRate.setText("N/A");
                    txtMinHeartRate.setText("N/A");
                    txtAvgHeartRate.setText(avg + " BPM");

                    updateGraph(new int[]{avg}, "Yearly Heart Rate");
                } else {
                    Log.d("DataError", "Yearly data not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }



    private String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return dateFormat.format(new Date());
    }

    private void displayNoDataMessage() {
        // 그래프에 데이터가 없음을 표시하는 메시지 또는 기본 데이터로 대체
        txtMaxHeartRate.setText("N/A");
        txtMinHeartRate.setText("N/A");
        txtAvgHeartRate.setText("N/A");

        heartRateGraph.removeAllSeries();
        LineGraphSeries<DataPoint> emptySeries = new LineGraphSeries<>(new DataPoint[]{
                new DataPoint(0, 0)
        });
        emptySeries.setColor(Color.GRAY);
        heartRateGraph.addSeries(emptySeries);
        heartRateGraph.getGridLabelRenderer().setHorizontalAxisTitle("No Data Available");
        heartRateGraph.getGridLabelRenderer().setVerticalAxisTitle("Heart Rate (BPM)");
    }

    private void updateGraph(int[] heartRates, String title) {
        DataPoint[] dataPoints = new DataPoint[heartRates.length];
        for (int i = 0; i < heartRates.length; i++) {
            dataPoints[i] = new DataPoint(i, heartRates[i]);
        }
        updateGraph(dataPoints, title);
    }

    private void updateGraph(DataPoint[] heartRates, String title) {
        heartRateGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(heartRates);

        series.setColor(Color.RED);
        series.setThickness(5);

        heartRateGraph.addSeries(series);
        heartRateGraph.getGridLabelRenderer().setHorizontalAxisTitle(title);
        heartRateGraph.getGridLabelRenderer().setVerticalAxisTitle("Heart Rate (BPM)");

        heartRateGraph.getViewport().setXAxisBoundsManual(true);
        heartRateGraph.getViewport().setMinX(0);
        heartRateGraph.getViewport().setMaxX(heartRates.length - 1);

        heartRateGraph.getViewport().setYAxisBoundsManual(true);
        heartRateGraph.getViewport().setMinY(0);
        heartRateGraph.getViewport().setMaxY(150);  // 적절한 심박수 범위 설정
    }
}