package com.example.caring01;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class StatisticsActivity extends AppCompatActivity {

    // Firebase 데이터베이스 참조
    private DatabaseReference databaseReference;

    // 현재 날짜와 주차를 계산하기 위한 캘린더 객체
    private Calendar calendar;

    // UI 요소
    private TextView txtHeartRateStatistics, txtSleepStatistics, txtMovementStatistics, txtToiletStatistics;
    private TextView weekTextView;
    private Button prevWeekButton, nextWeekButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        // Firebase Database 초기화
        databaseReference = FirebaseDatabase.getInstance().getReference("USER/StatsData");

        // 캘린더 초기화 (현재 날짜 기준)
        calendar = Calendar.getInstance();


        // UI 요소 초기화
        txtHeartRateStatistics = findViewById(R.id.txtHeartRateStatistics);
        txtSleepStatistics = findViewById(R.id.txtSleepStatistics);
        txtMovementStatistics = findViewById(R.id.txtMovementStatistics);
        txtToiletStatistics = findViewById(R.id.txtToiletStatistics);

        weekTextView = findViewById(R.id.weekTextView);
        prevWeekButton = findViewById(R.id.prevWeekButton);
        nextWeekButton = findViewById(R.id.nextWeekButton);

        // 초기 주 표시
        updateWeekTextView();

        // 이전/다음 주 버튼 클릭 리스너
        prevWeekButton.setOnClickListener(v -> {
            calendar.add(Calendar.WEEK_OF_YEAR, -1); // 이전 주로 이동
            updateWeekTextView();
            updateStatisticsFromFirebase();
        });

        nextWeekButton.setOnClickListener(v -> {
            calendar.add(Calendar.WEEK_OF_YEAR, 1); // 다음 주로 이동
            updateWeekTextView();
            updateStatisticsFromFirebase();
        });

        // 초기 Firebase 데이터 로드
        updateStatisticsFromFirebase();
    }

    // 현재 주를 텍스트뷰에 표시하는 메서드
    private void updateWeekTextView() {
        Calendar startOfWeek = (Calendar) calendar.clone();
        startOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        Calendar endOfWeek = (Calendar) calendar.clone();
        endOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM월 dd일", Locale.getDefault());
        String weekRange = dateFormat.format(startOfWeek.getTime()) + " ~ " + dateFormat.format(endOfWeek.getTime());
        weekTextView.setText(weekRange);
    }

    // Firebase에서 데이터를 가져오는 메서드
    private void updateStatisticsFromFirebase() {
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH) + 1; // Calendar.MONTH는 0부터 시작
        int currentWeek = calendar.get(Calendar.WEEK_OF_MONTH);

        // 심박수 데이터 가져오기
        String heartRatePath = "heartRate/" + currentYear + "/" + currentMonth + "/week" + currentWeek + "/Weekly average";
        fetchHeartRateData(heartRatePath);

        // 수면 데이터 가져오기
        String sleepPath = "sleepData/" + currentYear + "/" + currentMonth + "/week" + currentWeek + "/Weekly average";
        fetchSleepData(sleepPath);

        // 움직임 데이터 가져오기
        String movementPath = "steps/" + currentYear + "/" + currentMonth + "/week" + currentWeek + "/Weekly average";
        fetchMovementData(movementPath);

        // 화장실 데이터 가져오기
        String toiletPath = "toiletUsage/" + currentYear + "/" + currentMonth + "/week" + currentWeek + "/Weekly average";
        fetchToiletData(toiletPath);
    }

    private void fetchHeartRateData(String path) {
        databaseReference.child(path).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer heartRateAvg = snapshot.getValue(Integer.class);
                    String status = getHeartRateStatusText(heartRateAvg);
                    int color = getHeartRateStatusColor(heartRateAvg);
                    updateHeartRateUI(heartRateAvg, status, color);
                } else {
                    updateHeartRateUI(null, "데이터 없음", ContextCompat.getColor(StatisticsActivity.this, android.R.color.darker_gray));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("StatisticsActivity", "Firebase Error: " + error.getMessage());
            }
        });
    }

    private void fetchSleepData(String path) {
        databaseReference.child(path).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Double sleepAvg = snapshot.getValue(Double.class);
                    String status = getSleepStatusText(sleepAvg);
                    int color = getSleepStatusColor(sleepAvg);
                    updateSleepUI(sleepAvg, status, color);
                } else {
                    updateSleepUI(null, "데이터 없음", ContextCompat.getColor(StatisticsActivity.this, android.R.color.darker_gray));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("StatisticsActivity", "Firebase Error: " + error.getMessage());
            }
        });
    }

    private void fetchMovementData(String path) {
        databaseReference.child(path).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer movementAvg = snapshot.getValue(Integer.class);
                    String status = getMovementStatusText(movementAvg);
                    int color = getMovementStatusColor(movementAvg);
                    updateMovementUI(movementAvg, status, color);
                } else {
                    updateMovementUI(null, "데이터 없음", ContextCompat.getColor(StatisticsActivity.this, android.R.color.darker_gray));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("StatisticsActivity", "Firebase Error: " + error.getMessage());
            }
        });
    }

    private void fetchToiletData(String path) {
        databaseReference.child(path).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer toiletAvg = snapshot.getValue(Integer.class);
                    String status = getToiletStatusText(toiletAvg);
                    int color = getToiletStatusColor(toiletAvg);
                    updateToiletUI(toiletAvg, status, color);
                } else {
                    updateToiletUI(null, "데이터 없음", ContextCompat.getColor(StatisticsActivity.this, android.R.color.darker_gray));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("StatisticsActivity", "Firebase Error: " + error.getMessage());
            }
        });
    }

    // 상태 판단 로직 (각각 텍스트와 색상을 반환)
    private String getHeartRateStatusText(Integer value) {
        if (value == null) return "데이터 없음";
        if (value >= 60 && value <= 100) return "양호(적정)";
        if (value < 60) return "주의 : 심박수가 낮습니다.";
        return "주의 : 심박수가 높습니다.";
    }

    private int getHeartRateStatusColor(Integer value) {
        if (value == null) return ContextCompat.getColor(this, android.R.color.darker_gray);
        if (value >= 60 && value <= 100)
            return ContextCompat.getColor(this, android.R.color.holo_green_dark);
        if (value < 60)
            return ContextCompat.getColor(this, android.R.color.holo_red_dark);
        return ContextCompat.getColor(this, android.R.color.holo_red_dark);
    }

    private String getSleepStatusText(Double value) {
        if (value == null) return "데이터 없음";
        if (value >= 7 && value <= 8) return "양호(적정)";
        if (value < 7) return "보통 : 수면 시간이 부족합니다.";
        return "보통 : 수면 시간이 깁니다.";
    }

    private int getSleepStatusColor(Double value) {
        if (value == null) return ContextCompat.getColor(this, android.R.color.darker_gray);
        if (value >= 7 && value <= 8)
            return ContextCompat.getColor(this, android.R.color.holo_green_dark);
        if (value < 7)
            return ContextCompat.getColor(this, android.R.color.holo_orange_light);
        return ContextCompat.getColor(this, android.R.color.holo_orange_light);
    }

    private String getMovementStatusText(Integer value) {
        if (value == null) return "데이터 없음";
        if (value >= 5000) return "양호(적정)";
        if (value >= 3000) return "보통 : 활동량이 다소 적습니다.";
        return "주의 : 활동량이 매우 적습니다.";
    }

    private int getMovementStatusColor(Integer value) {
        if (value == null) return ContextCompat.getColor(this, android.R.color.darker_gray);
        if (value >= 5000)
            return ContextCompat.getColor(this, android.R.color.holo_green_dark);
        if (value >= 3000)
            return ContextCompat.getColor(this, android.R.color.holo_orange_light);
        return ContextCompat.getColor(this, android.R.color.holo_red_dark);
    }

    private String getToiletStatusText(Integer value) {
        if (value == null) return "데이터 없음";
        if (value >= 4 && value <= 6) return "양호(적정)";
        if (value < 4) return "주의 : 배뇨 횟수가 적습니다.";
        return "주의 : 배뇨 횟수가 많습니다.";
    }

    private int getToiletStatusColor(Integer value) {
        if (value == null) return ContextCompat.getColor(this, android.R.color.darker_gray);
        if (value >= 4 && value <= 6)
            return ContextCompat.getColor(this, android.R.color.holo_green_dark);
        if (value < 4)
            return ContextCompat.getColor(this, android.R.color.holo_red_dark);
        return ContextCompat.getColor(this, android.R.color.holo_red_dark);
    }

    // UI 업데이트 메서드
    private void updateHeartRateUI(Integer value, String status, int color) {
        if (value != null) {
            txtHeartRateStatistics.setText("이번주 평균 심박수는 " + value + " BPM입니다.\n" + status);
            txtHeartRateStatistics.setTextColor(color);
        } else {
            txtHeartRateStatistics.setText("심박수 데이터를 가져올 수 없습니다.");
            txtHeartRateStatistics.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        }
    }

    private void updateSleepUI(Double value, String status, int color) {
        if (value != null) {
            txtSleepStatistics.setText("이번주 평균 수면시간은 " + value + "시간입니다.\n" + status);
            txtSleepStatistics.setTextColor(color);
        } else {
            txtSleepStatistics.setText("수면 데이터를 가져올 수 없습니다.");
            txtSleepStatistics.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        }
    }

    private void updateMovementUI(Integer value, String status, int color) {
        if (value != null) {
            txtMovementStatistics.setText("이번주 평균 움직임은 " + value + "보입니다.\n" + status);
            txtMovementStatistics.setTextColor(color);
        } else {
            txtMovementStatistics.setText("움직임 데이터를 가져올 수 없습니다.");
            txtMovementStatistics.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        }
    }

    private void updateToiletUI(Integer value, String status, int color) {
        if (value != null) {
            txtToiletStatistics.setText("이번주의 배뇨 횟수는 " + value + "번입니다.\n" + status);
            txtToiletStatistics.setTextColor(color);
        } else {
            txtToiletStatistics.setText("화장실 데이터를 가져올 수 없습니다.");
            txtToiletStatistics.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        }
    }

}
