package com.example.caring01;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;

import java.util.Calendar;

public class activity_sleep_time_statistics extends AppCompatActivity {

    private GraphView sleepTimeGraph;
    private TextView weekTextView;
    private Button prevWeekButton, nextWeekButton;
    private Calendar currentStartDate; // 현재 표시 중인 주의 시작 날짜
    private final int maxWeeks = 4; // 기록 가능한 최대 주 수 (예시로 설정)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_time_statistics);

        sleepTimeGraph = findViewById(R.id.sleepTimeGraph);
        weekTextView = findViewById(R.id.weekTextView);
        prevWeekButton = findViewById(R.id.prevWeekButton);
        nextWeekButton = findViewById(R.id.nextWeekButton);

        // 현재 날짜 기준으로 시작
        currentStartDate = Calendar.getInstance();
        setToStartOfWeek(currentStartDate);
        updateWeekTextView();
        displaySleepDataForCurrentWeek();

        // 이전 주 버튼 클릭 리스너
        prevWeekButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentStartDate.add(Calendar.WEEK_OF_YEAR, -1);
                if (isDataAvailable(currentStartDate)) {
                    updateWeekTextView();
                    displaySleepDataForCurrentWeek();
                } else {
                    currentStartDate.add(Calendar.WEEK_OF_YEAR, 1); // 복구
                }
            }
        });

        // 다음 주 버튼 클릭 리스너
        nextWeekButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentStartDate.add(Calendar.WEEK_OF_YEAR, 1);
                if (isDataAvailable(currentStartDate)) {
                    updateWeekTextView();
                    displaySleepDataForCurrentWeek();
                } else {
                    currentStartDate.add(Calendar.WEEK_OF_YEAR, -1); // 복구
                }
            }
        });
    }

    // 주간 수면 데이터 표시
    private void displaySleepDataForCurrentWeek() {
        sleepTimeGraph.removeAllSeries();

        // 가상의 데이터 생성 (일주일)
        BarGraphSeries<DataPoint> sleepTimeSeries = new BarGraphSeries<>(new DataPoint[]{
                new DataPoint(1, 7), new DataPoint(2, 6),
                new DataPoint(3, 8), new DataPoint(4, 5),
                new DataPoint(5, 7), new DataPoint(6, 6),
                new DataPoint(7, 8)
        });
        sleepTimeSeries.setSpacing(20);
        sleepTimeGraph.addSeries(sleepTimeSeries);

        sleepTimeGraph.getViewport().setMinY(4);
        sleepTimeGraph.getViewport().setMaxY(10);
        sleepTimeGraph.getViewport().setYAxisBoundsManual(true);
    }

    // 주 텍스트 업데이트
    private void updateWeekTextView() {
        int month = currentStartDate.get(Calendar.MONTH) + 1;
        int startDay = currentStartDate.get(Calendar.DAY_OF_MONTH);
        Calendar endDate = (Calendar) currentStartDate.clone();
        endDate.add(Calendar.DAY_OF_MONTH, 6);
        int endDay = endDate.get(Calendar.DAY_OF_MONTH);

        weekTextView.setText(String.format("%d월 %d일 - %d일", month, startDay, endDay));
    }

    // 특정 날짜로 주의 시작 설정
    private void setToStartOfWeek(Calendar date) {
        date.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
    }

    // 데이터가 있는지 여부 확인 (가상의 조건)
    private boolean isDataAvailable(Calendar date) {
        // 예를 들어 최대 4주까지만 데이터가 있다고 가정
        Calendar currentDate = Calendar.getInstance();
        int weeksDifference = (int) ((currentDate.getTimeInMillis() - date.getTimeInMillis()) / (1000 * 60 * 60 * 24 * 7));
        return weeksDifference <= maxWeeks && weeksDifference >= 0;
    }
}
