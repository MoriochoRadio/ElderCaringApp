package com.example.caring01;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class activity_heart_rate_statistics extends AppCompatActivity {

    private GraphView heartRateGraph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_statistics);

        heartRateGraph = findViewById(R.id.heartRateGraph);

        // 가상 데이터 설정
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(1, 72),
                new DataPoint(2, 75),
                new DataPoint(3, 70),
                new DataPoint(4, 80),
                new DataPoint(5, 74),
                new DataPoint(6, 77),
                new DataPoint(7, 73)
        });

        heartRateGraph.addSeries(series);
        series.setTitle("심박수");

        // 축 설정
        heartRateGraph.getViewport().setScalable(true);
        heartRateGraph.getViewport().setScrollable(true);
        heartRateGraph.getViewport().setXAxisBoundsManual(true);
        heartRateGraph.getViewport().setYAxisBoundsManual(true);
        heartRateGraph.getViewport().setMinX(0);
        heartRateGraph.getViewport().setMaxX(7);
        heartRateGraph.getViewport().setMinY(60);
        heartRateGraph.getViewport().setMaxY(90);
    }
}
