package com.example.caring01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private TextView timeTextView;
    private Handler handler;
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView userNV = findViewById(R.id.userNV);


        // user 클릭 리스너 설정
        userNV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // UserActivity로 이동하는 인텐트
                Intent intent = new Intent(MainActivity.this, UserActivity.class);
                startActivity(intent);
            }
        });

        ImageView statisticNV = findViewById(R.id.statisticNV);


        // 통계 클릭 리스너 설정
        statisticNV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // StatisticsActivity로 이동하는 인텐트
                Intent intent = new Intent(MainActivity.this, StatisticsActivity.class);
                startActivity(intent);
            }
        });

        LinearLayout heartRateLayout = findViewById(R.id.heartRateLayout); // 심박수 레이아웃 참조

        // 클릭 리스너 설정: 심박수 레이아웃
        heartRateLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // HeartRateStatisticsActivity로 이동하는 인텐트
                Intent intent = new Intent(MainActivity.this, activity_heart_rate_statistics.class);
                startActivity(intent);
            }
        });

        // 수면 시간 레이아웃 참조
        LinearLayout sleepLayout = findViewById(R.id.SleepLayout);

        // 수면 시간 레이아웃 클릭 리스너 설정
        sleepLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity_sleep_time_statistics.class);
                startActivity(intent);
            }
        });

        // 움직임 레이아웃
        LinearLayout walkLayout = findViewById(R.id.WalkLayout);

        // 움직임 레이아웃 클릭 리스너 설정
        walkLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, activity_movement_statistics.class);
                startActivity(intent);
            }
        });

        // 화장실 레이아웃
        LinearLayout toiletLayout = findViewById(R.id.ToiletLayout);

        // 움직임 레이아웃 클릭 리스너 설정
        toiletLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ToiletActivity.class);
                startActivity(intent);
            }
        });



        timeTextView = findViewById(R.id.timeTextView);

        // Handler와 Runnable 설정
        handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                updateCurrentTime();
                handler.postDelayed(this, 1000); // 1초마다 갱신
            }
        };

        // Runnable 시작
        handler.post(runnable);
    }

    // 현재 시간 업데이트 메서드
    private void updateCurrentTime() {
        String currentTime = new SimpleDateFormat("MM. dd (E) HH:mm", Locale.getDefault()).format(new Date());
        timeTextView.setText(currentTime);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Handler의 Runnable 제거
        handler.removeCallbacks(runnable);
    }




    }
