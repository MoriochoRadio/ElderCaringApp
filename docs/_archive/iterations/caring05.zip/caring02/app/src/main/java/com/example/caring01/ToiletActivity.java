package com.example.caring01;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ToiletActivity extends AppCompatActivity {

    private TextView usageCountTextView, weekTextView;
    private ListView listView;
    private UsageAdapter usageAdapter;
    private List<UsageData> usageList;
    private DatabaseReference reference;

    FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toilet_statistics);

        usageCountTextView = findViewById(R.id.usageCountTextView);
        listView = findViewById(R.id.listView);
        weekTextView = findViewById(R.id.weekTextView);

        usageList = new ArrayList<>();
        usageAdapter = new UsageAdapter(this, usageList);
        listView.setAdapter(usageAdapter);

        // Firebase 초기화
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        reference = database.getReference("USER/StatsData/toiletUsage/11");

        // 버튼 클릭 리스너 설정
        findViewById(R.id.tab_daily).setOnClickListener(v -> loadDailyData());
        findViewById(R.id.tab_weekly).setOnClickListener(v -> loadWeeklyData());
        findViewById(R.id.tab_monthly).setOnClickListener(v -> loadMonthlyData());
        findViewById(R.id.tab_yearly).setOnClickListener(v -> loadYearlyData());

        // 기본적으로 월간 데이터를 로드
        loadDailyData();
    }

    private void loadDailyData() {
        reference.child("week1/10/22/Daily counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int dailyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("오늘 이용 횟수: " + dailyCount + "회");
                usageList.add(new UsageData("Day 22", dailyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void loadWeeklyData() {
        reference.child("week1/Weekly counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int weeklyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("이번 주 이용 횟수: " + weeklyCount + "회");
                usageList.add(new UsageData("Week 1", weeklyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("MainActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void loadMonthlyData() {
        reference.child("Monthly counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int monthlyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("이번 달 이용 횟수: " + monthlyCount + "회");
                usageList.add(new UsageData("Monthly Total", monthlyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void loadYearlyData() {
        // 연간 데이터의 경우 예시로 2024년 기준
        DatabaseReference yearlyReference = database.getReference("USER/StatsData/toiletUsage");
        yearlyReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int yearlyCount = 0;

                for (DataSnapshot monthSnapshot : snapshot.getChildren()) {
                    Integer monthlyCount = monthSnapshot.child("Monthly counts").getValue(Integer.class);
                    if (monthlyCount != null) {
                        yearlyCount += monthlyCount;
                    }
                }

                usageCountTextView.setText("올해 이용 횟수: " + yearlyCount + "회");
                usageList.add(new UsageData("Yearly Total", yearlyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("MainActivity", "Failed to read value.", error.toException());
            }
        });
    }
}
