package com.example.caring01;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class activity_heart_rate_statistics extends AppCompatActivity {

    private GraphView heartRateGraph;
    private TextView maxHeartRate, avgHeartRate, minHeartRate, dateTextView;
    private DatabaseReference databaseReference;
    private Date currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_statistics);

        // Firebase 초기화
        databaseReference = FirebaseDatabase.getInstance().getReference();

        // UI 요소 초기화
        heartRateGraph = findViewById(R.id.heartRateGraph);
        maxHeartRate = findViewById(R.id.maxHeartRate);
        avgHeartRate = findViewById(R.id.avgHeartRate);
        minHeartRate = findViewById(R.id.minHeartRate);
        dateTextView = findViewById(R.id.dateTextView);

        // 현재 날짜 초기화
        currentDate = new Date();
        updateDateTextView();

        // 초기 데이터 로드
        fetchHeartRateData(currentDate);

        // 날짜 변경 버튼 리스너 설정
        findViewById(R.id.prevButton).setOnClickListener(v -> {
            updateDate(-1);
            fetchHeartRateData(currentDate);
        });

        findViewById(R.id.nextButton).setOnClickListener(v -> {
            updateDate(1);
            fetchHeartRateData(currentDate);
        });
    }

    private void fetchHeartRateData(Date date) {
        // 날짜 포맷 설정
        SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy", Locale.getDefault());
        SimpleDateFormat sdfMonth = new SimpleDateFormat("MM", Locale.getDefault());
        SimpleDateFormat sdfDay = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        String year = sdfYear.format(date);
        String month = sdfMonth.format(date);
        String formattedDate = sdfDay.format(date);

        // 주차 계산
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int weekOfMonth = calendar.get(Calendar.WEEK_OF_MONTH);
        String week = "week" + weekOfMonth;

        // Firebase 경로 생성
        DatabaseReference path = databaseReference.child("USER")
                .child("StatsData")
                .child("heartRate")
                .child(year)
                .child(month)
                .child(week)
                .child(formattedDate);

        // 데이터 요청
        path.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Log.d("HeartRateActivity", "Data found: " + dataSnapshot.getValue());
                    updateChartWithData(dataSnapshot);
                } else {
                    Log.d("HeartRateActivity", "No data found.");
                    clearChart();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("HeartRateActivity", "데이터 로드 실패: " + databaseError.getMessage());
            }
        });
    }

    private void updateChartWithData(DataSnapshot dataSnapshot) {
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        int max = Integer.MIN_VALUE, min = Integer.MAX_VALUE, total = 0, count = 0;

        for (DataSnapshot hourSnapshot : dataSnapshot.getChildren()) {
            try {
                // 시간 (0~23)
                String key = hourSnapshot.getKey();
                if (key == null) {
                    Log.e("HeartRateActivity", "Hour key is null");
                    continue;
                }

                int hour = Integer.parseInt(key); // Key를 시간으로 변환
                Integer hourlyAverage = hourSnapshot.child("Hourly average").getValue(Integer.class);

                if (hourlyAverage == null) {
                    Log.e("HeartRateActivity", "Hourly average is null for hour: " + hour);
                    continue;
                }

                // 데이터 포인트 추가 (Hourly average만 사용)
                series.appendData(new DataPoint(hour, hourlyAverage), true, 24);

                // 통계 계산
                max = Math.max(max, hourlyAverage);
                min = Math.min(min, hourlyAverage);
                total += hourlyAverage;
                count++;
            } catch (NumberFormatException e) {
                Log.e("HeartRateActivity", "Invalid hour format: " + hourSnapshot.getKey(), e);
            } catch (Exception e) {
                Log.e("HeartRateActivity", "Unexpected error while processing data", e);
            }
        }

        // 그래프에 데이터 추가
        heartRateGraph.removeAllSeries();
        heartRateGraph.addSeries(series);

        // 통계 업데이트
        if (count > 0) {
            maxHeartRate.setText(max + " BPM");
            avgHeartRate.setText((total / count) + " BPM");
            minHeartRate.setText(min + " BPM");
        } else {
            maxHeartRate.setText("-- BPM");
            avgHeartRate.setText("-- BPM");
            minHeartRate.setText("-- BPM");
        }
    }


    private void clearChart() {
        heartRateGraph.removeAllSeries();
        maxHeartRate.setText("-- BPM");
        avgHeartRate.setText("-- BPM");
        minHeartRate.setText("-- BPM");
    }

    private void updateDate(int delta) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DATE, delta);
        currentDate = calendar.getTime();
        updateDateTextView();
    }

    private void updateDateTextView() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        dateTextView.setText(sdf.format(currentDate));
    }
}
