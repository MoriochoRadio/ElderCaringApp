package com.example.caring01;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class activity_toilet_statistics extends AppCompatActivity {

    private TextView tabDaily, tabWeekly, tabMonthly, tabYearly, dateTextView;
    private TextView usageCountTextView, weekTextView;
    private ListView listView;
    private UsageAdapter usageAdapter;
    private List<UsageData> usageList;
    private DatabaseReference reference;

    private Calendar currentWeek; // 현재 주를 저장할 캘린더 객체
    private SimpleDateFormat dateFormat;

    private Button prevButton, nextButton; // 이전, 다음 버튼
    private String currentView = "daily"; // 현재 보는 단위 (daily, weekly, monthly, yearly)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toilet_statistics);

        usageCountTextView = findViewById(R.id.usageCountTextView);
        weekTextView = findViewById(R.id.weekTextView);
        listView = findViewById(R.id.listView);

        tabDaily = findViewById(R.id.tab_daily);
        tabWeekly = findViewById(R.id.tab_weekly);
        tabMonthly = findViewById(R.id.tab_monthly);
        tabYearly = findViewById(R.id.tab_yearly);

        usageList = new ArrayList<>();
        usageAdapter = new UsageAdapter(this, usageList);
        listView.setAdapter(usageAdapter);

        // Firebase 초기화
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        reference = database.getReference("USER/StatsData/toiletUsage/11");

        // 날짜 포맷
        dateFormat = new SimpleDateFormat("MM월 dd일", Locale.getDefault());

        // 현재 주를 기준으로 설정
        currentWeek = Calendar.getInstance();
        showCurrentWeekRange();

        // 버튼 설정
        prevButton = findViewById(R.id.prevWeekButton);
        nextButton = findViewById(R.id.nextWeekButton);

        // 이전 버튼 클릭 리스너
        prevButton.setOnClickListener(v -> {
            moveTime(-1); // 이전 시간으로 이동
        });

        // 다음 버튼 클릭 리스너
        nextButton.setOnClickListener(v -> {
            moveTime(1); // 다음 시간으로 이동
        });

        // 탭 버튼 클릭 리스너 설정
        findViewById(R.id.tab_daily).setOnClickListener(v -> {
            currentView = "daily";
            loadDailyData(); // 일별 데이터 로드
        });

        findViewById(R.id.tab_weekly).setOnClickListener(v -> {
            currentView = "weekly";
            loadWeeklyData(); // 주별 데이터 로드
        });

        findViewById(R.id.tab_monthly).setOnClickListener(v -> {
            currentView = "monthly";
            loadMonthlyData(); // 월별 데이터 로드
        });

        findViewById(R.id.tab_yearly).setOnClickListener(v -> {
            currentView = "yearly";
            loadYearlyData(); // 연별 데이터 로드
        });

        // 기본적으로 일별 데이터를 로드
        loadDailyData();
    }

    // 시간 범위 이동 (일, 주, 월, 년에 따라)
    private void moveTime(int direction) {
        switch (currentView) {
            case "daily":
                currentWeek.add(Calendar.DAY_OF_YEAR, direction);
                showCurrentDay();
                loadDailyData();
                break;
            case "weekly":
                currentWeek.add(Calendar.WEEK_OF_YEAR, direction);
                showCurrentWeekRange();
                loadWeeklyData();
                break;
            case "monthly":
                currentWeek.add(Calendar.MONTH, direction);
                showCurrentMonth();
                loadMonthlyData();
                break;
            case "yearly":
                currentWeek.add(Calendar.YEAR, direction);
                showCurrentYear();
                loadYearlyData();
                break;
        }
    }

    // 현재 일만 표시
    private void showCurrentDay() {
        String formattedDay = dateFormat.format(currentWeek.getTime());
        weekTextView.setText(formattedDay);
    }


    // 현재 주차 표시
    private void showCurrentWeekRange() {
        Calendar startOfWeek = (Calendar) currentWeek.clone();
        startOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        Calendar endOfWeek = (Calendar) currentWeek.clone();
        endOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);

        String weekRange = dateFormat.format(startOfWeek.getTime()) + " ~ " + dateFormat.format(endOfWeek.getTime());
        weekTextView.setText(weekRange);
    }

    // 현재 월 표시
    private void showCurrentMonth() {
        Calendar startOfMonth = (Calendar) currentWeek.clone();
        startOfMonth.set(Calendar.DAY_OF_MONTH, 1);

        Calendar endOfMonth = (Calendar) currentWeek.clone();
        endOfMonth.set(Calendar.DAY_OF_MONTH, currentWeek.getActualMaximum(Calendar.DAY_OF_MONTH));

        String monthRange = new SimpleDateFormat("MM월", Locale.getDefault()).format(startOfMonth.getTime()) + " ~ " +
                new SimpleDateFormat("MM월 dd일", Locale.getDefault()).format(endOfMonth.getTime());
        weekTextView.setText(monthRange);
    }

    // 현재 연도 표시
    private void showCurrentYear() {
        int year = currentWeek.get(Calendar.YEAR);
        weekTextView.setText(year + "년");
    }

    // 일별 데이터 로드
    // 일별 데이터 로드
    private void loadDailyData() {
        usageList.clear();
        // 오늘 날짜를 포맷팅
        String currentYear = String.valueOf(currentWeek.get(Calendar.YEAR));
        String currentMonth = String.format(Locale.getDefault(), "%02d", currentWeek.get(Calendar.MONTH) + 1);
        String todayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(currentWeek.getTime());

        // 주 계산 (월 기준으로 주차 계산)
        int weekOfMonth = currentWeek.get(Calendar.WEEK_OF_MONTH);
        String weekKey = "week" + weekOfMonth;

        // Firebase 경로
        String firebasePath = String.format("USER/StatsData/toiletUsage/%s/%s/%s/%s",
                currentYear, currentMonth, weekKey, todayKey);

        reference.getRoot().child(firebasePath).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // 데이터를 읽어옴
                if (snapshot.exists()) {
                    // Firebase에서 데이터를 가져와 사용
                    Integer sleepCount = snapshot.child("count").getValue(Integer.class);
                    String sleepCountText = sleepCount != null ? sleepCount + "시간" : "0시간";

                    // UI 업데이트
                    usageCountTextView.setText("오늘 이용 횟수: " + sleepCountText);
                    usageList.add(new UsageData(todayKey, sleepCountText));
                    usageAdapter.notifyDataSetChanged();
                } else {
                    usageCountTextView.setText("오늘 수면 데이터 없음");
                    usageAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }


    // 주별 데이터 로드
    private void loadWeeklyData() {
        usageList.clear();
        int weekOfYear = currentWeek.get(Calendar.WEEK_OF_YEAR);
        String weekKey = "week" + weekOfYear;

        reference.child(weekKey + "/Weekly counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int weeklyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("이번주 이용 횟수: " + weeklyCount + "회");

                for (int day = 1; day <= 7; day++) {
                    String dayKey = "Day " + day;
                    Integer dailyCount = snapshot.child(dayKey + "/Daily counts").getValue(Integer.class);
                    if (dailyCount != null) {
                        usageList.add(new UsageData(dayKey, dailyCount + "회"));
                    }
                }

                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    // 월별 데이터 로드
    private void loadMonthlyData() {
        reference.child("Monthly counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int monthlyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("이번 달 이용 횟수: " + monthlyCount + "회");
                usageList.add(new UsageData("Monthly Total", monthlyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    // 연별 데이터 로드
    private void loadYearlyData() {
        DatabaseReference yearlyReference = FirebaseDatabase.getInstance().getReference("USER/StatsData/toiletUsage");
        yearlyReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int yearlyCount = 0;

                for (DataSnapshot monthSnapshot : snapshot.getChildren()) {
                    Integer monthlyCount = monthSnapshot.child("Monthly counts").getValue(Integer.class);
                    if (monthlyCount != null) {
                        yearlyCount += monthlyCount;
                    }
                }

                usageCountTextView.setText("올해 이용 횟수: " + yearlyCount + "회");
                usageList.add(new UsageData("Yearly Total", yearlyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }
}
