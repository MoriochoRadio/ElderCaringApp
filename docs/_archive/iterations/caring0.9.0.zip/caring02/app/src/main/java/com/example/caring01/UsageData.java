package com.example.caring01;

public class UsageData {
    private String time;
    private String duration;

    public UsageData() { }

    public UsageData(String time, String duration) {
        this.time = time;
        this.duration = duration;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
