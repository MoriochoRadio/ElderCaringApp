package com.example.caring01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class UsageAdapter extends ArrayAdapter<UsageData> {

    public UsageAdapter(Context context, List<UsageData> usageList) {
        super(context, 0, usageList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_usage, parent, false);
        }

        UsageData usageData = getItem(position);

        TextView timeTextView = convertView.findViewById(R.id.timeTextView);
        TextView durationTextView = convertView.findViewById(R.id.durationTextView);

        if (usageData != null) {
            timeTextView.setText(usageData.getTime());
            durationTextView.setText(usageData.getDuration());
        }

        return convertView;
    }
}
