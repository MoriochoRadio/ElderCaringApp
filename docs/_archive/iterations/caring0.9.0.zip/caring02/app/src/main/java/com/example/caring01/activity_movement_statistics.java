package com.example.caring01;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class activity_movement_statistics extends AppCompatActivity {

    private GraphView walkGraph;
    private TextView txtWalk, tabDaily, tabWeekly, tabMonthly, tabYearly;
    private Button prevButton, nextButton;
    private DatabaseReference databaseReference;
    private Map<String, Integer> dailySteps = new HashMap<>();

    private Calendar currentCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movement_statistics);

        walkGraph = findViewById(R.id.WalkGraph);
        txtWalk = findViewById(R.id.txtWalk);

        tabDaily = findViewById(R.id.tab_daily);
        tabWeekly = findViewById(R.id.tab_weekly);
        tabMonthly = findViewById(R.id.tab_monthly);
        tabYearly = findViewById(R.id.tab_yearly);

        prevButton = findViewById(R.id.prevWeekButton);
        nextButton = findViewById(R.id.nextWeekButton);

        // 초기에는 이전/다음 버튼 숨기기
        hideNavigationButtons();

        // Firebase 데이터베이스 참조 가져오기
        databaseReference = FirebaseDatabase.getInstance().getReference("DAILY_STEPS");

        // 현재 날짜 캘린더 초기화
        currentCalendar = Calendar.getInstance();

        fetchAndDisplayData();

        // 탭 클릭 리스너 설정
        tabDaily.setOnClickListener(v -> {
            setTabSelected(tabDaily);
            hideNavigationButtons();
            displayDailyAverage();
        });

        tabWeekly.setOnClickListener(v -> {
            setTabSelected(tabWeekly);
            showNavigationButtons();
            displayWeeklyAverage();
        });

        tabMonthly.setOnClickListener(v -> {
            setTabSelected(tabMonthly);
            hideNavigationButtons();
            displayMonthlyAverage();
        });

        tabYearly.setOnClickListener(v -> {
            setTabSelected(tabYearly);
            hideNavigationButtons();
            displayYearlyAverage();
        });

        // 이전/다음 버튼 클릭 리스너
        prevButton.setOnClickListener(v -> {
            if (tabWeekly.isSelected()) {
                currentCalendar.add(Calendar.WEEK_OF_YEAR, -1);
                displayWeeklyAverage();
            } else if (tabMonthly.isSelected()) {
                currentCalendar.add(Calendar.MONTH, -1);
                displayMonthlyAverage();
            }
        });

        nextButton.setOnClickListener(v -> {
            if (tabWeekly.isSelected()) {
                currentCalendar.add(Calendar.WEEK_OF_YEAR, 1);
                displayWeeklyAverage();
            } else if (tabMonthly.isSelected()) {
                currentCalendar.add(Calendar.MONTH, 1);
                displayMonthlyAverage();
            }
        });
    }

    private void fetchAndDisplayData() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dailySteps.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String date = snapshot.getKey();
                    int steps = Integer.parseInt(snapshot.getValue(String.class));
                    dailySteps.put(date, steps);

                    Log.d("FirebaseData", "Date: " + date + ", Steps: " + steps);
                }

                int totalSteps = 0;
                for (int steps : dailySteps.values()) {
                    totalSteps += steps;
                }
                txtWalk.setText(String.valueOf(totalSteps));

                displayDailyAverage(); // 기본적으로 일별 평균 표시
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("FirebaseData", "DatabaseError", databaseError.toException());
            }
        });
    }

    private void setTabSelected(TextView selectedTab) {
        // 모든 탭을 선택 해제
        tabDaily.setSelected(false);
        tabWeekly.setSelected(false);
        tabMonthly.setSelected(false);
        tabYearly.setSelected(false);

        // 선택된 탭만 선택 상태로 설정
        selectedTab.setSelected(true);
    }

    private void displayDailyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        int i = 0;

        for (Map.Entry<String, Integer> entry : dailySteps.entrySet()) {
            int steps = entry.getValue();
            series.appendData(new DataPoint(i, steps), true, dailySteps.size());
            Log.d("GraphData", "Index: " + i + ", Steps: " + steps);
            i++;
        }

        series.setColor(Color.BLUE);
        series.setThickness(5);

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Days");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Steps");

        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(dailySteps.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000);
    }

    private void displayWeeklyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

        List<Integer> weeklyAverages = calculateWeeklyAverage();
        for (int i = 0; i < weeklyAverages.size(); i++) {
            series.appendData(new DataPoint(i, weeklyAverages.get(i)), true, weeklyAverages.size());
        }

        series.setColor(Color.GREEN);
        series.setThickness(5);

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Weeks");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Average Steps");

        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(weeklyAverages.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000);
    }

    private void displayMonthlyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

        List<Integer> monthlyAverages = calculateMonthlyAverage();
        for (int i = 0; i < monthlyAverages.size(); i++) {
            series.appendData(new DataPoint(i, monthlyAverages.get(i)), true, monthlyAverages.size());
        }

        series.setColor(Color.RED);
        series.setThickness(5);

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Months");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Average Steps");

        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(monthlyAverages.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000);
    }

    private void displayYearlyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

        List<Integer> yearlyAverages = calculateYearlyAverage();
        for (int i = 0; i < yearlyAverages.size(); i++) {
            series.appendData(new DataPoint(i, yearlyAverages.get(i)), true, yearlyAverages.size());
        }

        series.setColor(Color.MAGENTA);
        series.setThickness(5);

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Years");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Average Steps");

        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(yearlyAverages.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000);
    }

    private List<Integer> calculateWeeklyAverage() {
        List<Integer> weeklyAverages = new ArrayList<>();
        int sum = 0, count = 0;

        for (int steps : dailySteps.values()) {
            sum += steps;
            count++;
            if (count == 7) {
                weeklyAverages.add(sum / 7);
                sum = 0;
                count = 0;
            }
        }

        if (count != 0) {
            weeklyAverages.add(sum / count);
        }

        return weeklyAverages;
    }

    private List<Integer> calculateMonthlyAverage() {
        List<Integer> monthlyAverages = new ArrayList<>();
        int sum = 0, count = 0;

        for (int steps : dailySteps.values()) {
            sum += steps;
            count++;
            if (count == 30) {
                monthlyAverages.add(sum / 30);
                sum = 0;
                count = 0;
            }
        }

        if (count != 0) {
            monthlyAverages.add(sum / count);
        }

        return monthlyAverages;
    }

    private List<Integer> calculateYearlyAverage() {
        List<Integer> yearlyAverages = new ArrayList<>();
        int sum = 0, count = 0;

        for (int steps : dailySteps.values()) {
            sum += steps;
            count++;
            if (count == 365) {
                yearlyAverages.add(sum / 365);
                sum = 0;
                count = 0;
            }
        }

        if (count != 0) {
            yearlyAverages.add(sum / count);
        }

        return yearlyAverages;
    }

    private void showNavigationButtons() {
        prevButton.setVisibility(View.VISIBLE);
        nextButton.setVisibility(View.VISIBLE);
    }

    private void hideNavigationButtons() {
        prevButton.setVisibility(View.GONE);
        nextButton.setVisibility(View.GONE);
    }
}
