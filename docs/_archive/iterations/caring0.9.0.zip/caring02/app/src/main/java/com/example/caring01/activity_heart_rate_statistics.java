package com.example.caring01;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class activity_heart_rate_statistics extends AppCompatActivity {

    private TextView txtHeartRate, txtBpm, tabDaily, tabWeekly, tabMonthly, tabYearly, dateTextView;
    private DatabaseReference databaseReference;
    private Date currentDate;
    private String period;
    private GraphView heartRateGraph;
    private TextView maxHeartRate, avgHeartRate, minHeartRate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_statistics);

        // Firebase 데이터베이스 참조 초기화
        databaseReference = FirebaseDatabase.getInstance().getReference();

        // 현재 날짜 초기화
        currentDate = new Date();

        // UI 요소 참조
        txtHeartRate = findViewById(R.id.txtHeartRate);
        txtBpm = findViewById(R.id.txtBpm);
        tabDaily = findViewById(R.id.tab_daily);
        tabWeekly = findViewById(R.id.tab_weekly);
        tabMonthly = findViewById(R.id.tab_monthly);
        tabYearly = findViewById(R.id.tab_yearly);
        dateTextView = findViewById(R.id.dateTextView);
        heartRateGraph = findViewById(R.id.heartRateGraph);
        maxHeartRate = findViewById(R.id.maxHeartRate);
        avgHeartRate = findViewById(R.id.avgHeartRate);
        minHeartRate = findViewById(R.id.minHeartRate);

        // 날짜 변경 버튼 클릭 리스너 설정
        findViewById(R.id.prevButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDate(-1);  // 이전 날짜로 변경
                fetchDataForDate(currentDate);
            }
        });

        findViewById(R.id.nextButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDate(1);  // 다음 날짜로 변경
                fetchDataForDate(currentDate);
            }
        });

        // 기간별 통계 탭 클릭 리스너 설정
        tabDaily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                period = "daily";
                fetchPeriodData(period);
            }
        });

        tabWeekly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                period = "weekly";
                fetchPeriodData(period);
            }
        });

        tabMonthly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                period = "monthly";
                fetchPeriodData(period);
            }
        });

        tabYearly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                period = "yearly";
                fetchPeriodData(period);
            }
        });

        // 초기 데이터 로드
        period = "daily";
        fetchDataForDate(currentDate);
    }

    // 날짜 업데이트 메서드
    private void updateDate(int delta) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        if (period.equals("daily")) {
            calendar.add(Calendar.DATE, delta);
        } else if (period.equals("weekly")) {
            calendar.add(Calendar.WEEK_OF_YEAR, delta);
        } else if (period.equals("monthly")) {
            calendar.add(Calendar.MONTH, delta);
        } else if (period.equals("yearly")) {
            calendar.add(Calendar.YEAR, delta);
        }
        currentDate = calendar.getTime();
        updateDateTextView();
    }

    // 날짜 텍스트뷰 업데이트 메서드
    private void updateDateTextView() {
        SimpleDateFormat sdf;
        if (period.equals("daily")) {
            sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        } else if (period.equals("weekly")) {
            sdf = new SimpleDateFormat("yyyy년 w주", Locale.getDefault());
        } else if (period.equals("monthly")) {
            sdf = new SimpleDateFormat("yyyy-MM", Locale.getDefault());
        } else {  // yearly
            sdf = new SimpleDateFormat("yyyy", Locale.getDefault());
        }
        dateTextView.setText(sdf.format(currentDate));
    }

    // 특정 날짜의 데이터를 가져오는 메서드
    private void fetchDataForDate(Date date) {
        String formattedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(date);
        databaseReference.child("HeartRateData").child(formattedDate)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // 데이터를 차트에 표시
                            updateChartWithData(dataSnapshot);
                        } else {
                            // 데이터가 없으면 차트를 공백으로 유지
                            clearChart();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("HeartRateActivity", "데이터 로드 실패: " + databaseError.getMessage());
                    }
                });
    }

    // 특정 기간의 데이터를 가져오는 메서드
    private void fetchPeriodData(String period) {
        // period 값에 따라 데이터베이스에서 적절한 데이터를 가져와야 함
        updateDateTextView();
        // 실제 데이터 가져오는 로직 추가 필요
    }

    // 차트를 데이터로 업데이트하는 메서드
    private void updateChartWithData(DataSnapshot dataSnapshot) {
        // 차트를 업데이트하는 로직을 추가합니다
        // 예시: 차트 라이브러리를 이용해 데이터를 반영
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
            long timestamp = snapshot.child("timestamp").getValue(Long.class);
            int heartRate = snapshot.child("heartRate").getValue(Integer.class);
            series.appendData(new DataPoint(timestamp, heartRate), true, 100);
        }
        heartRateGraph.removeAllSeries();
        heartRateGraph.addSeries(series);
        // 최고, 평균, 최저 심박수 업데이트 예시
        maxHeartRate.setText(dataSnapshot.child("maxHeartRate").getValue(String.class) + " BPM");
        avgHeartRate.setText(dataSnapshot.child("avgHeartRate").getValue(String.class) + " BPM");
        minHeartRate.setText(dataSnapshot.child("minHeartRate").getValue(String.class) + " BPM");
    }

    // 차트를 공백으로 유지하는 메서드
    private void clearChart() {
        // 차트를 공백으로 유지하는 로직을 추가합니다
        heartRateGraph.removeAllSeries();
        maxHeartRate.setText("-- BPM");
        avgHeartRate.setText("-- BPM");
        minHeartRate.setText("-- BPM");
    }
}
