package com.example.caring01;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class activity_toilet_statistics extends AppCompatActivity {

    private TextView usageCountTextView, weekTextView;
    private ListView listView;
    private UsageAdapter usageAdapter;
    private List<UsageData> usageList;
    private DatabaseReference reference;

    private Calendar currentWeek; // 현재 주를 저장할 캘린더 객체
    private SimpleDateFormat dateFormat;

    private Button prevWeekButton, nextWeekButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toilet_statistics);

        usageCountTextView = findViewById(R.id.usageCountTextView);
        weekTextView = findViewById(R.id.weekTextView);
        listView = findViewById(R.id.listView);

        usageList = new ArrayList<>();
        usageAdapter = new UsageAdapter(this, usageList);
        listView.setAdapter(usageAdapter);

        // Firebase 초기화
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        reference = database.getReference("USER/StatsData/toiletUsage/11");

        // 날짜 포맷
        dateFormat = new SimpleDateFormat("MM월 dd일", Locale.getDefault());

        // 현재 주를 기준으로 설정
        currentWeek = Calendar.getInstance();
        showCurrentWeekRange();

        // 주간 이동 버튼 설정
        prevWeekButton = findViewById(R.id.prevWeekButton);
        nextWeekButton = findViewById(R.id.nextWeekButton);

        // 주간 이동 버튼 초기 가시성 설정: 숨기기
        prevWeekButton.setVisibility(View.GONE);
        nextWeekButton.setVisibility(View.GONE);
        weekTextView.setVisibility(View.GONE);

        // 주간 이동 버튼 클릭 리스너
        prevWeekButton.setOnClickListener(v -> {
            currentWeek.add(Calendar.WEEK_OF_YEAR, -1);
            showCurrentWeekRange();
            loadWeeklyData();
        });

        nextWeekButton.setOnClickListener(v -> {
            currentWeek.add(Calendar.WEEK_OF_YEAR, 1);
            showCurrentWeekRange();
            loadWeeklyData();
        });

        // 탭 버튼 클릭 리스너 설정
        findViewById(R.id.tab_daily).setOnClickListener(v -> {
            hideWeekNavigation();
            loadDailyData();
        });

        findViewById(R.id.tab_weekly).setOnClickListener(v -> {
            showWeekNavigation();
            loadWeeklyData();
        });

        findViewById(R.id.tab_monthly).setOnClickListener(v -> {
            hideWeekNavigation();
            loadMonthlyData();
        });

        findViewById(R.id.tab_yearly).setOnClickListener(v -> {
            hideWeekNavigation();
            loadYearlyData();
        });

        // 기본적으로 월간 데이터를 로드
        loadDailyData();
    }

    private void showWeekNavigation() {
        prevWeekButton.setVisibility(View.VISIBLE);
        nextWeekButton.setVisibility(View.VISIBLE);
        weekTextView.setVisibility(View.VISIBLE);
        showCurrentWeekRange();
    }

    private void hideWeekNavigation() {
        prevWeekButton.setVisibility(View.GONE);
        nextWeekButton.setVisibility(View.GONE);
        weekTextView.setVisibility(View.GONE);
    }

    private void showCurrentWeekRange() {
        Calendar startOfWeek = (Calendar) currentWeek.clone();
        startOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        Calendar endOfWeek = (Calendar) currentWeek.clone();
        endOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);

        String weekRange = dateFormat.format(startOfWeek.getTime()) + " ~ " + dateFormat.format(endOfWeek.getTime());
        weekTextView.setText(weekRange);
    }

    private void loadDailyData() {
        reference.child("week1/10/22/Daily counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int dailyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("오늘 이용 횟수: " + dailyCount + "회");
                usageList.add(new UsageData("Day 22", dailyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void loadWeeklyData() {
        usageList.clear();
        int weekOfYear = currentWeek.get(Calendar.WEEK_OF_YEAR);
        String weekKey = "week" + weekOfYear;

        reference.child(weekKey + "/Weekly counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int weeklyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("이번주 이용 횟수: " + weeklyCount + "회");

                for (int day = 1; day <= 7; day++) {
                    String dayKey = "Day " + day;
                    Integer dailyCount = snapshot.child(dayKey + "/Daily counts").getValue(Integer.class);
                    if (dailyCount != null) {
                        usageList.add(new UsageData(dayKey, dailyCount + "회"));
                    }
                }

                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void loadMonthlyData() {
        reference.child("Monthly counts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int monthlyCount = snapshot.getValue(Integer.class) != null ? snapshot.getValue(Integer.class) : 0;
                usageCountTextView.setText("이번 달 이용 횟수: " + monthlyCount + "회");
                usageList.add(new UsageData("Monthly Total", monthlyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void loadYearlyData() {
        DatabaseReference yearlyReference = FirebaseDatabase.getInstance().getReference("USER/StatsData/toiletUsage");
        yearlyReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usageList.clear();
                int yearlyCount = 0;

                for (DataSnapshot monthSnapshot : snapshot.getChildren()) {
                    Integer monthlyCount = monthSnapshot.child("Monthly counts").getValue(Integer.class);
                    if (monthlyCount != null) {
                        yearlyCount += monthlyCount;
                    }
                }

                usageCountTextView.setText("올해 이용 횟수: " + yearlyCount + "회");
                usageList.add(new UsageData("Yearly Total", yearlyCount + "회"));
                usageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("ToiletActivity", "Failed to read value.", error.toException());
            }
        });
    }
}
