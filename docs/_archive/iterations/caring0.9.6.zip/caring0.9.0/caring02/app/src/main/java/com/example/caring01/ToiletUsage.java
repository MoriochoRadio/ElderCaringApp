package com.example.caring01;

public class ToiletUsage {
    private String count;
    private Integer duration;
    private String startTime;
    private String endTime;
    private double dailyavg;
    private String dailycount;
    private String day;


    // 기본 생성자
    public ToiletUsage() {}

    // 매개변수를 받는 생성자
    public ToiletUsage(String count ,String startTime, String endTime, Integer duration) {
        this.count = count;
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public ToiletUsage(String day, String dailycount, double dailyavg){
        this.day = day;
        this.dailycount = dailycount;
        this.dailyavg = dailyavg;
    }

    public String getDay(){
        return day;
    }

    public void setDay(String day){
        this.day = day;
    }

    public String getCount(){
        return count;
    }

    public void setCount(String count){
        this.count = count;
    }
    // Getter and Setter
    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public double getDailyAvg(){
        return dailyavg;
    }

    public void setDailyAvg(double dailyavg){
        this.dailyavg = dailyavg;
    }

    public String getDailyCount(){
        return dailycount;
    }

    public void setDailyCount(String dailycount){
        this.dailycount = dailycount;
    }
}
