package com.example.caring01;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class activity_walk_statistics extends AppCompatActivity {

    private GraphView walkGraph;
    private TextView txtWalk;
    private DatabaseReference databaseReference;

    private TextView tabDaily, tabWeekly, tabMonthly;

    // 일별 걸음 데이터를 저장할 변수
    private Map<String, Integer> dailySteps = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_walk_statistics);

        walkGraph = findViewById(R.id.WalkGraph);
        txtWalk = findViewById(R.id.txtWalk);

        tabDaily = findViewById(R.id.tab_daily);
        tabWeekly = findViewById(R.id.tab_weekly);
        tabMonthly = findViewById(R.id.tab_monthly);

        // Firebase 데이터베이스 참조 가져오기
        databaseReference = FirebaseDatabase.getInstance().getReference("DAILY_STEPS");

        fetchAndDisplayData();

        // 탭 클릭 리스너 설정
        tabDaily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayDailyAverage();
            }
        });

        tabWeekly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayWeeklyAverage();
            }
        });

        tabMonthly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayMonthlyAverage();
            }
        });
    }

    private void fetchAndDisplayData() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dailySteps.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String date = snapshot.getKey();
                    int steps = Integer.parseInt(snapshot.getValue(String.class));
                    dailySteps.put(date, steps);

                    // 데이터 확인을 위한 로그 추가
                    Log.d("FirebaseData", "Date: " + date + ", Steps: " + steps);
                }

                // 총 걸음 수 계산
                int totalSteps = 0;
                for (int steps : dailySteps.values()) {
                    totalSteps += steps;
                }
                txtWalk.setText(String.valueOf(totalSteps));

                displayDailyAverage();  // 기본적으로 일별 평균 표시
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void displayDailyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        int i = 0;

        for (Map.Entry<String, Integer> entry : dailySteps.entrySet()) {
            int steps = entry.getValue();
            series.appendData(new DataPoint(i, steps), true, dailySteps.size());

            // 그래프에 추가된 데이터 확인용 로그
            Log.d("GraphData", "Index: " + i + ", Steps: " + steps);
            i++;
        }

        series.setColor(Color.BLUE); // 차트 색상 설정
        series.setThickness(5); // 차트 라인 두께 설정

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Days");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Steps");

        // 뷰포트 설정
        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(dailySteps.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000); // 예상 걸음 수 최대치
    }

    private void displayWeeklyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

        List<Integer> weeklyAverages = calculateWeeklyAverage();
        for (int i = 0; i < weeklyAverages.size(); i++) {
            series.appendData(new DataPoint(i, weeklyAverages.get(i)), true, weeklyAverages.size());
        }

        series.setColor(Color.GREEN);
        series.setThickness(5);

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Weeks");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Average Steps");

        // 뷰포트 설정
        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(weeklyAverages.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000);
    }

    private void displayMonthlyAverage() {
        walkGraph.removeAllSeries();
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

        List<Integer> monthlyAverages = calculateMonthlyAverage();
        for (int i = 0; i < monthlyAverages.size(); i++) {
            series.appendData(new DataPoint(i, monthlyAverages.get(i)), true, monthlyAverages.size());
        }

        series.setColor(Color.RED);
        series.setThickness(5);

        walkGraph.addSeries(series);
        walkGraph.getGridLabelRenderer().setHorizontalAxisTitle("Months");
        walkGraph.getGridLabelRenderer().setVerticalAxisTitle("Average Steps");

        // 뷰포트 설정
        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(monthlyAverages.size() - 1);

        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(30000);
    }

    private List<Integer> calculateWeeklyAverage() {
        List<Integer> weeklyAverages = new ArrayList<>();
        int sum = 0, count = 0;

        for (int steps : dailySteps.values()) {
            sum += steps;
            count++;
            if (count == 7) {
                weeklyAverages.add(sum / 7);
                sum = 0;
                count = 0;
            }
        }

        if (count != 0) { // 남은 일수 평균 추가
            weeklyAverages.add(sum / count);
        }

        return weeklyAverages;
    }

    private List<Integer> calculateMonthlyAverage() {
        List<Integer> monthlyAverages = new ArrayList<>();
        int sum = 0, count = 0;

        for (int steps : dailySteps.values()) {
            sum += steps;
            count++;
            if (count == 30) {  // 가정: 한 달은 30일
                monthlyAverages.add(sum / 30);
                sum = 0;
                count = 0;
            }
        }

        if (count != 0) { // 남은 일수 평균 추가
            monthlyAverages.add(sum / count);
        }

        return monthlyAverages;
    }
}
