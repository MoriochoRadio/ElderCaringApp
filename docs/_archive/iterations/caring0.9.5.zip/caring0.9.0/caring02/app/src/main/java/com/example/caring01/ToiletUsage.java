package com.example.caring01;

public class ToiletUsage {
    private int duration;
    private String startTime;
    private String endTime;

    // 기본 생성자
    public ToiletUsage() {}

    // 매개변수를 받는 생성자
    public ToiletUsage(String startTime, String endTime, int duration) {
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    // Getter and Setter
    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
