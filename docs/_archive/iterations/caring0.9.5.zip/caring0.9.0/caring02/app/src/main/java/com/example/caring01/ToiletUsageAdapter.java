package com.example.caring01;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ToiletUsageAdapter extends RecyclerView.Adapter<ToiletUsageAdapter.ToiletUsageViewHolder> {

    private List<ToiletUsage> toiletUsageList;

    public ToiletUsageAdapter(activity_toilet_statistics activityToiletStatistics, List<ToiletUsage> toiletUsageList) {
        this.toiletUsageList = toiletUsageList;
    }

    @NonNull
    @Override
    public ToiletUsageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_usage, parent, false);
        return new ToiletUsageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ToiletUsageViewHolder holder, int position) {
        ToiletUsage toiletUsage = toiletUsageList.get(position);
        // 초 단위 duration을 분으로 변환
        int durationInMinutes = toiletUsage.getDuration() / 60;
        int remainingSeconds = toiletUsage.getDuration() % 60;

        holder.durationTextView.setText("Duration: " + durationInMinutes + " min " + remainingSeconds + " sec");
        holder.endTimeTextView.setText("End Time: " + toiletUsage.getEndTime());
        holder.durationTextView.setText("Duration: " + toiletUsage.getDuration() + " minutes");
    }

    @Override
    public int getItemCount() {
        return toiletUsageList.size();
    }

    public static class ToiletUsageViewHolder extends RecyclerView.ViewHolder {

        TextView startTimeTextView;
        TextView endTimeTextView;
        TextView durationTextView;

        public ToiletUsageViewHolder(View itemView) {
            super(itemView);
            startTimeTextView = itemView.findViewById(R.id.startTimeTextView);
            endTimeTextView = itemView.findViewById(R.id.endTimeTextView);
            durationTextView = itemView.findViewById(R.id.durationTextView);
        }
    }
}
