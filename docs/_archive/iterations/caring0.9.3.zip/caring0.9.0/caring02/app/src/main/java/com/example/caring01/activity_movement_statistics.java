package com.example.caring01;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class activity_movement_statistics extends AppCompatActivity {

    private GraphView walkGraph;
    private TextView txtWalk, dateTextView;
    private Button prevButton, nextButton;
    private DatabaseReference databaseReference;
    private Calendar currentCalendar;
    private Date currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movement_statistics);

        walkGraph = findViewById(R.id.WalkGraph);
        txtWalk = findViewById(R.id.txtWalk);
        dateTextView = findViewById(R.id.dateTextView);

        prevButton = findViewById(R.id.prevWeekButton);
        nextButton = findViewById(R.id.nextWeekButton);

        databaseReference = FirebaseDatabase.getInstance().getReference("USER/StatsData/steps");
        currentCalendar = Calendar.getInstance();

        // 현재 날짜 초기화
        currentDate = new Date();
        updateDateTextView();

        // 초기 데이터 로드
        fetchMovementData(currentDate);

        // 날짜 변경 버튼 리스너 설정
        findViewById(R.id.prevWeekButton).setOnClickListener(v -> {
            updateDate(-1);
            fetchMovementData(currentDate);
        });

        findViewById(R.id.nextWeekButton).setOnClickListener(v -> {
            updateDate(1);
            fetchMovementData(currentDate);
        });
    }

    private void fetchMovementData(Date date) {
        // 날짜 포맷 설정
        SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy", Locale.getDefault());
        SimpleDateFormat sdfMonth = new SimpleDateFormat("MM", Locale.getDefault());
        SimpleDateFormat sdfDay = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        String year = sdfYear.format(date);
        String month = sdfMonth.format(date);
        String formattedDate = sdfDay.format(date);

        // 주차 계산
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int weekOfMonth = calendar.get(Calendar.WEEK_OF_MONTH);
        String week = "week" + weekOfMonth;

        // Firebase 경로 생성
        DatabaseReference path = databaseReference.child("USER")
                .child("StatsData")
                .child("steps")
                .child(year)
                .child(month)
                .child(week)
                .child(formattedDate);

        // 데이터 요청
        path.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Log.d("activity_movement_statistics", "Data found: " + dataSnapshot.getValue());
                    updateChartWithData(dataSnapshot);
                } else {
                    Log.d("activity_movement_statistics", "No data found.");
                    clearChart();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("activity_movement_statistics", "데이터 로드 실패: " + databaseError.getMessage());
            }
        });
    }

    private void updateChartWithData(DataSnapshot dataSnapshot) {
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        int max = Integer.MIN_VALUE, min = Integer.MAX_VALUE, total = 0, count = 0;

        for (DataSnapshot hourSnapshot : dataSnapshot.getChildren()) {
            try {
                // 시간 (0~23)
                String key = hourSnapshot.getKey();
                if (key == null) {
                    Log.e("activity_movement_statistics", "Hour key is null");
                    continue;
                }

                int hour = Integer.parseInt(key); // Key를 시간으로 변환
                Integer hourlyAverage = hourSnapshot.child("Hourly average").getValue(Integer.class);

                if (hourlyAverage == null) {
                    Log.e("activity_movement_statistics", "Hourly average is null for hour: " + hour);
                    continue;
                }

                // 데이터 포인트 추가 (Hourly average만 사용)
                series.appendData(new DataPoint(hour, hourlyAverage), true, 24);

                // 통계 계산
                max = Math.max(max, hourlyAverage);
                min = Math.min(min, hourlyAverage);
                total += hourlyAverage;
                count++;
            } catch (NumberFormatException e) {
                Log.e("activity_movement_statistics", "Invalid hour format: " + hourSnapshot.getKey(), e);
            } catch (Exception e) {
                Log.e("activity_movement_statistics", "Unexpected error while processing data", e);
            }
        }

        // 그래프에 데이터 추가
        walkGraph.removeAllSeries();
        walkGraph.addSeries(series);


    }

    private void clearChart() {
        walkGraph.removeAllSeries();
        txtWalk.setText("--");
    }

    private void updateDate(int delta) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DATE, delta);
        currentDate = calendar.getTime();
        updateDateTextView();
    }

    private void updateDateTextView() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        dateTextView.setText(sdf.format(currentDate));
    }

    private void setGraphViewSettings() {
        // X축 설정: 0 ~ 23 시간대
        walkGraph.getViewport().setXAxisBoundsManual(true);
        walkGraph.getViewport().setMinX(0);
        walkGraph.getViewport().setMaxX(23);

        // Y축 설정: 데이터 범위에 맞는 값 설정
        walkGraph.getViewport().setYAxisBoundsManual(true);
        walkGraph.getViewport().setMinY(0);
        walkGraph.getViewport().setMaxY(10000); // 예시: 최대값 10000으로 설정
    }
}
